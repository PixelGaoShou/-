# 开发辅助脚本

这些脚本只用于维护本项目，构建模组本身不需要运行它们。

- `generate_data.py`：重新生成物品模型、配方、标签、进度和语言文件，**可以独立运行**。
  输出目录可用环境变量 `GAW_RESOURCES_OUT` 覆盖（默认写入 `src/main/resources`）。
- `generate_textures.py`：生成剑、末影苹果、头盔图标与盔甲图层贴图。需要一份 1.20.1 原版 `assets/minecraft/textures`（从客户端 jar 解包），
  通过环境变量 `GAW_VANILLA` 指定；输出目录可用 `GAW_ASSETS_OUT` 指定。脚本只把原版剑/苹果/头盔当作**轮廓蒙版**，所有颜色都由本模组自己绘制。
- `generate_helmet_model.py`：生成 3D 头盔模型贴图 `golden_apple_helmet_3d.png`（可用 `GAW_ARMOR_OUT` 指定输出目录）。
- `generate_models.py`：写出头盔物品模型。
- `generate_recipe_card.py`：生成 `docs/recipes.png`，依赖原版物品贴图与 Windows 中文字体。

运行示例：

```bash
python tools/generate_data.py
set GAW_VANILLA=path\to\assets\minecraft\textures
python tools/generate_textures.py
python tools/generate_helmet_model.py
python tools/generate_recipe_card.py
```

> 注意：原版盔甲图层只会读取红色通道再做材质染色，所以 `golden_apple_layer_1.png` 必须保持单色相金色，否则戴在身上会偏紫。
