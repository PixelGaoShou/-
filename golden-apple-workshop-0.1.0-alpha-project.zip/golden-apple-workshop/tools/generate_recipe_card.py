"""Generate a Chinese recipe cheat sheet for the README / mod page."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
VANILLA = ROOT / "vanilla-assets/assets/minecraft/textures/item"
MOD = ROOT / "src/main/resources/assets/goldenappleworkshop/textures/item"
DOCS = ROOT / "docs"
DOCS.mkdir(exist_ok=True)

FONT_BOLD = "C:/Windows/Fonts/msyhbd.ttc"
FONT = "C:/Windows/Fonts/msyh.ttc"

W, H = 1400, 960
BG = (28, 20, 15, 255)
CARD = (44, 33, 24, 255)
CARD_EDGE = (111, 78, 31, 255)
GOLD = (235, 181, 61, 255)
CREAM = (248, 232, 199, 255)
MUTED = (189, 165, 132, 255)
SLOT = (31, 23, 18, 255)
SLOT_EDGE = (84, 61, 38, 255)

img = Image.new("RGBA", (W, H), BG)
d = ImageDraw.Draw(img)
title_font = ImageFont.truetype(FONT_BOLD, 38)
sub_font = ImageFont.truetype(FONT, 17)
card_font = ImageFont.truetype(FONT_BOLD, 22)
small_font = ImageFont.truetype(FONT, 15)
count_font = ImageFont.truetype(FONT_BOLD, 18)

# Header.
d.text((34, 24), "金苹果工坊 · 合成配方", font=title_font, fill=GOLD)
d.text((37, 76), "Minecraft 1.20.1  ·  Fabric  ·  长按右键可以“啃”这些武器", font=sub_font, fill=MUTED)
d.line((34, 108, W - 34, 108), fill=(86, 60, 34, 255), width=2)

def icon(folder, name, size=40):
    im = Image.open(folder / f"{name}.png").convert("RGBA")
    return im.resize((size, size), Image.Resampling.NEAREST)

def draw_slot(x, y, item=None, size=40):
    d.rounded_rectangle((x, y, x + size, y + size), radius=5, fill=SLOT, outline=SLOT_EDGE, width=1)
    if item:
        im = icon(item[0], item[1], size - 8)
        img.alpha_composite(im, (x + 4, y + 4))

def draw_arrow(x, y):
    d.line((x, y, x + 26, y), fill=GOLD, width=3)
    d.polygon([(x + 26, y - 7), (x + 40, y), (x + 26, y + 7)], fill=GOLD)

recipes = [
    {
        "name": "金苹果剑",
        "kind": "有序合成",
        "grid": {(1, 0): ("vanilla", "golden_apple"), (1, 1): ("vanilla", "golden_apple"), (1, 2): ("vanilla", "stick")},
        "result": "golden_apple_sword",
        "count": 1,
    },
    {
        "name": "附魔金苹果剑",
        "kind": "有序合成",
        "grid": {(1, 0): ("vanilla", "golden_apple"), (1, 1): ("vanilla", "golden_apple"), (1, 2): ("vanilla", "stick")},
        "result": "enchanted_golden_apple_sword",
        "count": 1,
        "note": "附魔金苹果 ×2",
    },
    {
        "name": "胡萝卜剑",
        "kind": "有序合成",
        "grid": {(1, 0): ("vanilla", "carrot"), (1, 1): ("vanilla", "carrot"), (1, 2): ("vanilla", "stick")},
        "result": "carrot_sword",
        "count": 1,
    },
    {
        "name": "法棍面包剑",
        "kind": "有序合成",
        "grid": {(1, 0): ("vanilla", "bread"), (1, 1): ("vanilla", "bread"), (1, 2): ("vanilla", "stick")},
        "result": "baguette_sword",
        "count": 1,
    },
    {
        "name": "蜂蜜剑",
        "kind": "有序合成",
        "grid": {(1, 0): ("vanilla", "honeycomb"), (1, 1): ("vanilla", "honeycomb"), (1, 2): ("vanilla", "stick")},
        "result": "honey_sword",
        "count": 1,
    },
    {
        "name": "末影苹果",
        "kind": "无序合成",
        "grid": {(0, 0): ("vanilla", "apple"), (1, 0): ("vanilla", "ender_pearl"), (0, 1): ("vanilla", "ender_pearl"), (1, 1): ("vanilla", "sugar")},
        "result": "ender_apple",
        "count": 2,
    },
    {
        "name": "金苹果头盔",
        "kind": "无序合成",
        "grid": {(0, 0): ("vanilla", "gold_ingot"), (1, 0): ("vanilla", "gold_ingot"), (2, 0): ("vanilla", "gold_ingot"),
                 (1, 1): ("vanilla", "golden_apple"), (0, 2): ("vanilla", "gold_ingot"), (2, 2): ("vanilla", "gold_ingot")},
        "result": "golden_apple_helmet",
        "count": 1,
    },
]

card_w, card_h = 325, 382
for index, recipe in enumerate(recipes):
    col, row = index % 4, index // 4
    x = 24 + col * 345
    y = 126 + row * 410
    d.rounded_rectangle((x, y, x + card_w, y + card_h), radius=14, fill=CARD, outline=CARD_EDGE, width=2)
    d.text((x + 20, y + 16), recipe["name"], font=card_font, fill=CREAM)
    d.text((x + 20, y + 50), recipe["kind"], font=small_font, fill=MUTED)

    gx, gy = x + 20, y + 86
    for gyy in range(3):
        for gxx in range(3):
            draw_slot(gx + gxx * 42, gy + gyy * 42)
    for (gxx, gyy), (folder, name) in recipe["grid"].items():
        source = VANILLA if folder == "vanilla" else MOD
        draw_slot(gx + gxx * 42, gy + gyy * 42, (source, name))

    draw_arrow(x + 164, y + 148)
    draw_slot(x + 226, y + 122, (MOD, recipe["result"]), size=64)
    if recipe["count"] > 1:
        d.text((x + 238, y + 192), f"×{recipe['count']}", font=count_font, fill=GOLD)

    if recipe.get("note"):
        d.text((x + 20, y + 322), recipe["note"], font=small_font, fill=MUTED)

# Footer.
d.line((34, H - 54, W - 34, H - 54), fill=(86, 60, 34, 255), width=2)
d.text((37, H - 42), "提示：剑类武器每次“啃咬”消耗耐久而不是消失；啃完还可以继续当武器用。", font=sub_font, fill=CREAM)
d.text((W - 180, H - 42), "Golden Apple Workshop", font=small_font, fill=MUTED)

img.save(DOCS / "recipes.png")
print(DOCS / "recipes.png")
