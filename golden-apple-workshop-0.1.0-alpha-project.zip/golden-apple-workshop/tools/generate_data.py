"""Generate item models, recipes, tags, advancement and language files."""
import json
from pathlib import Path

import os
ROOT = Path(__file__).resolve().parents[1]
RES = Path(os.environ.get("GAW_RESOURCES_OUT", str(ROOT / "src/main/resources")))
ASSETS = RES / "assets/goldenappleworkshop"
DATA = RES / "data"
MOD = "goldenappleworkshop"

SWORDS = [
    "golden_apple_sword",
    "enchanted_golden_apple_sword",
    "carrot_sword",
    "baguette_sword",
    "honey_sword",
]
ITEMS = SWORDS + ["ender_apple", "golden_apple_helmet"]


def dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


# Models ---------------------------------------------------------------------
for item in SWORDS:
    dump(ASSETS / f"models/item/{item}.json", {
        "parent": "minecraft:item/handheld",
        "textures": {"layer0": f"{MOD}:item/{item}"},
    })

for item in ("ender_apple", "golden_apple_helmet"):
    dump(ASSETS / f"models/item/{item}.json", {
        "parent": "minecraft:item/generated",
        "textures": {"layer0": f"{MOD}:item/{item}"},
    })

# Recipes --------------------------------------------------------------------
def shaped(pattern, key, result, count=1):
    return {
        "type": "minecraft:crafting_shaped",
        "pattern": pattern,
        "key": {k: {"item": v} for k, v in key.items()},
        "result": {"item": f"{MOD}:{result}", "count": count},
    }


def shapeless(ingredients, result, count=1):
    return {
        "type": "minecraft:crafting_shapeless",
        "ingredients": [{"item": ingredient} for ingredient in ingredients],
        "result": {"item": f"{MOD}:{result}", "count": count},
    }


dump(DATA / "goldenappleworkshop/recipes/golden_apple_sword.json",
     shaped([" G ", " G ", " S "], {"G": "minecraft:golden_apple", "S": "minecraft:stick"}, "golden_apple_sword"))
dump(DATA / "goldenappleworkshop/recipes/enchanted_golden_apple_sword.json",
     shaped([" E ", " E ", " S "], {"E": "minecraft:enchanted_golden_apple", "S": "minecraft:stick"},
            "enchanted_golden_apple_sword"))
dump(DATA / "goldenappleworkshop/recipes/carrot_sword.json",
     shaped([" C ", " C ", " S "], {"C": "minecraft:carrot", "S": "minecraft:stick"}, "carrot_sword"))
dump(DATA / "goldenappleworkshop/recipes/baguette_sword.json",
     shaped([" B ", " B ", " S "], {"B": "minecraft:bread", "S": "minecraft:stick"}, "baguette_sword"))
dump(DATA / "goldenappleworkshop/recipes/honey_sword.json",
     shaped([" H ", " H ", " S "], {"H": "minecraft:honeycomb", "S": "minecraft:stick"}, "honey_sword"))
dump(DATA / "goldenappleworkshop/recipes/ender_apple.json",
     shapeless(["minecraft:apple", "minecraft:ender_pearl", "minecraft:ender_pearl", "minecraft:sugar"],
               "ender_apple", 2))
dump(DATA / "goldenappleworkshop/recipes/golden_apple_helmet.json",
     shapeless(["minecraft:golden_apple", "minecraft:gold_ingot", "minecraft:gold_ingot",
                "minecraft:gold_ingot", "minecraft:gold_ingot"], "golden_apple_helmet"))

# Tags -----------------------------------------------------------------------
dump(DATA / "minecraft/tags/items/swords.json", {
    "replace": False,
    "values": [f"{MOD}:{item}" for item in SWORDS],
})
dump(DATA / "minecraft/tags/items/head_armor.json", {
    "replace": False,
    "values": [f"{MOD}:golden_apple_helmet"],
})
dump(DATA / "minecraft/tags/items/piglin_loved.json", {
    "replace": False,
    "values": [f"{MOD}:golden_apple_helmet"],
})
dump(DATA / "minecraft/tags/items/trimmable_armor.json", {
    "replace": False,
    "values": [f"{MOD}:golden_apple_helmet"],
})
dump(DATA / f"{MOD}/tags/items/tasty_swords.json", {
    "replace": False,
    "values": [f"{MOD}:{item}" for item in SWORDS],
})

# Advancements ---------------------------------------------------------------
dump(DATA / f"{MOD}/advancements/root.json", {
    "display": {
        "icon": {"item": f"{MOD}:golden_apple_sword"},
        "title": {"translate": f"advancements.{MOD}.root.title"},
        "description": {"translate": f"advancements.{MOD}.root.description"},
        "frame": "task",
        "background": "minecraft:textures/block/gold_block.png",
        "show_toast": True,
        "announce_to_chat": True,
    },
    "criteria": {
        "has_golden_apple_sword": {
            "trigger": "minecraft:inventory_changed",
            "conditions": {"items": [{"items": [f"{MOD}:golden_apple_sword"]}]},
        }
    },
})

criteria = {item: {
    "trigger": "minecraft:inventory_changed",
    "conditions": {"items": [{"items": [f"{MOD}:{item}"]}]},
} for item in ITEMS}

dump(DATA / f"{MOD}/advancements/full_menu.json", {
    "parent": f"{MOD}:root",
    "display": {
        "icon": {"item": f"{MOD}:enchanted_golden_apple_sword"},
        "title": {"translate": f"advancements.{MOD}.full_menu.title"},
        "description": {"translate": f"advancements.{MOD}.full_menu.description"},
        "frame": "challenge",
        "show_toast": True,
        "announce_to_chat": True,
        "hidden": False,
    },
    "criteria": criteria,
    "requirements": [[item] for item in ITEMS],
})

# Language -------------------------------------------------------------------
EN = {
    "itemGroup.goldenappleworkshop.main": "Golden Apple Workshop",
    "item.goldenappleworkshop.golden_apple_sword": "Golden Apple Sword",
    "item.goldenappleworkshop.enchanted_golden_apple_sword": "Enchanted Golden Apple Sword",
    "item.goldenappleworkshop.carrot_sword": "Carrot Sword",
    "item.goldenappleworkshop.baguette_sword": "Baguette Sword",
    "item.goldenappleworkshop.honey_sword": "Honey Sword",
    "item.goldenappleworkshop.ender_apple": "Ender Apple",
    "item.goldenappleworkshop.golden_apple_helmet": "Golden Apple Helmet",
    "tooltip.goldenappleworkshop.golden_apple_sword.hit": "On hit: 35% chance to heal 1 heart and gain Absorption",
    "tooltip.goldenappleworkshop.golden_apple_sword.eat": "Hold right-click: eat for hunger, Regeneration and Absorption",
    "tooltip.goldenappleworkshop.golden_apple_sword.cost": "Each bite costs 14 durability (8s cooldown)",
    "tooltip.goldenappleworkshop.enchanted_golden_apple_sword.hit": "On hit: 60% chance to heal, gain buffs and weaken the target",
    "tooltip.goldenappleworkshop.enchanted_golden_apple_sword.eat": "Hold right-click: a full meal of Regeneration II, Absorption II, Resistance and Fire Resistance",
    "tooltip.goldenappleworkshop.enchanted_golden_apple_sword.cost": "Each bite costs 24 durability (20s cooldown)",
    "tooltip.goldenappleworkshop.carrot_sword.hit": "On hit: 30% chance for Speed and Jump Boost; 10% chance to drop a carrot",
    "tooltip.goldenappleworkshop.carrot_sword.eat": "Hold right-click: eat for Speed II and Jump Boost II",
    "tooltip.goldenappleworkshop.carrot_sword.cost": "Each bite costs 10 durability (4s cooldown)",
    "tooltip.goldenappleworkshop.baguette_sword.hit": "On hit: launch the target and slow it briefly",
    "tooltip.goldenappleworkshop.baguette_sword.eat": "Hold right-click: eat for a hearty Strength snack",
    "tooltip.goldenappleworkshop.baguette_sword.cost": "Each bite costs 12 durability (6s cooldown)",
    "tooltip.goldenappleworkshop.honey_sword.hit": "On hit: 50% chance to coat the target in sticky honey (Slowness + Weakness)",
    "tooltip.goldenappleworkshop.honey_sword.eat": "Hold right-click: eat for Regeneration and Speed",
    "tooltip.goldenappleworkshop.honey_sword.cost": "Each bite costs 10 durability (5s cooldown)",
    "tooltip.goldenappleworkshop.ender_apple.teleport": "Hold right-click: teleport 8-24 blocks in a random direction",
    "tooltip.goldenappleworkshop.ender_apple.safe": "Grants Resistance and Slow Falling; avoids lava and solid walls",
    "tooltip.goldenappleworkshop.ender_apple.cost": "Consumed on use (8s cooldown)",
    "tooltip.goldenappleworkshop.golden_apple_helmet.regen": "While worn: at 8+ hunger and below full health, Regeneration every 5s",
    "tooltip.goldenappleworkshop.golden_apple_helmet.hunger": "The healing slowly consumes hunger",
    "tooltip.goldenappleworkshop.golden_apple_helmet.piglin": "Piglins treat you as wearing gold",
    "message.goldenappleworkshop.ender_apple.failed": "The Ender Apple found no safe landing spot... you feel dizzy.",
    "advancements.goldenappleworkshop.root.title": "The Golden Apple Workshop",
    "advancements.goldenappleworkshop.root.description": "Craft a Golden Apple Sword and begin a deliciously dangerous cooking experiment.",
    "advancements.goldenappleworkshop.full_menu.title": "The Full Tasting Menu",
    "advancements.goldenappleworkshop.full_menu.description": "Collect all seven pieces of Golden Apple Workshop equipment.",
}

ZH = {
    "itemGroup.goldenappleworkshop.main": "金苹果工坊",
    "item.goldenappleworkshop.golden_apple_sword": "金苹果剑",
    "item.goldenappleworkshop.enchanted_golden_apple_sword": "附魔金苹果剑",
    "item.goldenappleworkshop.carrot_sword": "胡萝卜剑",
    "item.goldenappleworkshop.baguette_sword": "法棍面包剑",
    "item.goldenappleworkshop.honey_sword": "蜂蜜剑",
    "item.goldenappleworkshop.ender_apple": "末影苹果",
    "item.goldenappleworkshop.golden_apple_helmet": "金苹果头盔",
    "tooltip.goldenappleworkshop.golden_apple_sword.hit": "攻击：35% 概率回复 1 颗心并获得伤害吸收",
    "tooltip.goldenappleworkshop.golden_apple_sword.eat": "长按右键：食用，回复饥饿并获得生命恢复与伤害吸收",
    "tooltip.goldenappleworkshop.golden_apple_sword.cost": "每咬一口消耗 14 点耐久（8 秒冷却）",
    "tooltip.goldenappleworkshop.enchanted_golden_apple_sword.hit": "攻击：60% 概率回复生命、获得增益并削弱目标",
    "tooltip.goldenappleworkshop.enchanted_golden_apple_sword.eat": "长按右键：丰盛一餐，获得生命恢复 II、伤害吸收 II、抗性提升与抗火",
    "tooltip.goldenappleworkshop.enchanted_golden_apple_sword.cost": "每咬一口消耗 24 点耐久（20 秒冷却）",
    "tooltip.goldenappleworkshop.carrot_sword.hit": "攻击：30% 概率获得速度与跳跃提升，10% 概率让目标掉落胡萝卜",
    "tooltip.goldenappleworkshop.carrot_sword.eat": "长按右键：食用，获得速度 II 与跳跃提升 II",
    "tooltip.goldenappleworkshop.carrot_sword.cost": "每咬一口消耗 10 点耐久（4 秒冷却）",
    "tooltip.goldenappleworkshop.baguette_sword.hit": "攻击：把目标击飞，并附加短暂缓慢",
    "tooltip.goldenappleworkshop.baguette_sword.eat": "长按右键：食用，获得一份扎实的力量加成",
    "tooltip.goldenappleworkshop.baguette_sword.cost": "每咬一口消耗 12 点耐久（6 秒冷却）",
    "tooltip.goldenappleworkshop.honey_sword.hit": "攻击：50% 概率让目标沾满蜂蜜，陷入缓慢与虚弱",
    "tooltip.goldenappleworkshop.honey_sword.eat": "长按右键：食用，获得生命恢复与速度",
    "tooltip.goldenappleworkshop.honey_sword.cost": "每咬一口消耗 10 点耐久（5 秒冷却）",
    "tooltip.goldenappleworkshop.ender_apple.teleport": "长按右键：向随机方向传送 8~24 格",
    "tooltip.goldenappleworkshop.ender_apple.safe": "传送后获得抗性提升与缓降，并尽量避开岩浆与实心墙体",
    "tooltip.goldenappleworkshop.ender_apple.cost": "每次食用消耗 1 个（8 秒冷却）",
    "tooltip.goldenappleworkshop.golden_apple_helmet.regen": "穿戴时：饥饿值 ≥ 8 且未满血，每 5 秒获得生命恢复",
    "tooltip.goldenappleworkshop.golden_apple_helmet.hunger": "治疗会缓慢消耗饥饿值",
    "tooltip.goldenappleworkshop.golden_apple_helmet.piglin": "猪灵会把你视为穿着金质装备",
    "message.goldenappleworkshop.ender_apple.failed": "末影苹果没有找到安全的落点……你感到一阵眩晕。",
    "advancements.goldenappleworkshop.root.title": "金苹果工坊",
    "advancements.goldenappleworkshop.root.description": "制作一把金苹果剑，开始这场美味又危险的料理实验。",
    "advancements.goldenappleworkshop.full_menu.title": "全店试吃",
    "advancements.goldenappleworkshop.full_menu.description": "集齐金苹果工坊的全部 7 件装备。",
}

dump(ASSETS / "lang/en_us.json", EN)
dump(ASSETS / "lang/zh_cn.json", ZH)

pack = RES / "pack.mcmeta"
pack.write_text(json.dumps({
    "pack": {
        "pack_format": 15,
        "description": "Golden Apple Workshop resources",
    }
}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

print("Generated models, recipes, tags, advancements and language files.")
