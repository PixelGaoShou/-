"""Write the golden apple helmet item + armour layer models."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "src/main/resources/assets/goldenappleworkshop"
ITEMS = ASSETS / "models/item"
ITEMS.mkdir(parents=True, exist_ok=True)

(ITEMS / "golden_apple_helmet.json").write_text(
    '{\n  "parent": "minecraft:item/generated",\n'
    '  "textures": {\n    "layer0": "goldenappleworkshop:item/golden_apple_helmet"\n  }\n}\n',
    encoding="utf-8",
)

# Used by the 3D item model (e.g. dropped / item frame / GUI variants).
(ITEMS / "golden_apple_helmet_3d.json").write_text(
    '{\n  "parent": "minecraft:item/generated",\n'
    '  "textures": {\n    "layer0": "goldenappleworkshop:item/golden_apple_helmet"\n  }\n}\n',
    encoding="utf-8",
)
print("Helmet item models written")
