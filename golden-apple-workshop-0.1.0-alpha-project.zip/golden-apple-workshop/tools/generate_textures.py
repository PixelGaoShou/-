"""Generate the Golden Apple Workshop textures.

Run: python tools/generate_textures.py

Swords share the vanilla sword silhouette as a mask. Each material gets its
own 3D-lit palette: a hue-correct base with a highlight -> midtone -> shadow
ramp running from the spine to the cutting edge.

The helmet uses the vanilla gold armour renderer (it reuses the GOLD armor
material), so the armour sheet has to look right through vanilla's armour
shader: it only samples the RED channel and tints it with the material colour
(gold = vec3(1.0, 0.92, 0.6)). Every pixel of the sheet therefore stays on a
single warm gold hue - blue/violet pixels would render as a muddy purple.
"""
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
import os
ASSETS = Path(os.environ.get("GAW_ASSETS_OUT", str(ROOT / "src/main/resources/assets/goldenappleworkshop")))
TEX_ITEM = ASSETS / "textures/item"
TEX_ARMOR = ASSETS / "textures/models/armor"
VANILLA = Path(os.environ.get("GAW_VANILLA", str(ROOT / "vanilla-assets/assets/minecraft/textures")))

for directory in (TEX_ITEM, TEX_ARMOR):
    directory.mkdir(parents=True, exist_ok=True)


def rgb(hex_color):
    hex_color = hex_color.lstrip("#")
    return tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))


def lit(base, top=1.0, top_right=0.93, top_left=0.97, right=0.80, left=0.60, bottom=0.32):
    """3D-lit palette from a base colour and a brightness ramp."""
    base = base if isinstance(base, tuple) else rgb(base)

    def shade(k):
        return tuple(max(0, min(255, int(c * k))) for c in base) + (255,)

    return {
        "top": shade(top),
        "top_right": shade(top_right),
        "top_left": shade(top_left),
        "right": shade(right),
        "left": shade(left),
        "bottom": shade(bottom),
    }


WOOD = lit("#9a6b3c", 1.0, 0.92, 0.96, 0.80, 0.62, 0.36)
DARK_WOOD = lit("#7a4f2a", 1.0, 0.92, 0.96, 0.78, 0.60, 0.34)

PALETTES = {
    # Apple gold: warm amber blade, white-hot tip, red apple crest on the guard.
    "golden_apple": {
        "blade": lit("#f9b42a", 1.0, 0.94, 0.97, 0.82, 0.66, 0.40),
        "guard": lit("#d68518", 0.96, 0.88, 0.92, 0.76, 0.56, 0.30),
        "handle": WOOD,
    },
    # Enchanted: lavender crystal blade; the guard stays gold so the silhouette reads.
    "enchanted_golden_apple": {
        "blade": lit("#be8afa", 1.0, 0.93, 0.96, 0.74, 0.55, 0.32),
        "guard": lit("#fac24a", 0.97, 0.89, 0.93, 0.78, 0.58, 0.32),
        "handle": DARK_WOOD,
    },
    # Carrot: orange root with green leafy guard.
    "carrot": {
        "blade": lit("#f6942a", 1.0, 0.93, 0.97, 0.82, 0.64, 0.38),
        "guard": lit("#68be3c", 0.95, 0.86, 0.90, 0.72, 0.54, 0.32),
        "handle": WOOD,
    },
    # Baguette: golden crust, floury top facet.
    "baguette": {
        "blade": lit("#e8ae68", 1.0, 0.95, 0.97, 0.86, 0.72, 0.52),
        "guard": lit("#c48446", 0.95, 0.87, 0.91, 0.74, 0.54, 0.30),
        "handle": DARK_WOOD,
    },
    # Honey: glossy amber blade with a honeycomb guard.
    "honey": {
        "blade": lit("#ffcc52", 1.0, 0.95, 0.98, 0.88, 0.72, 0.48),
        "guard": lit("#ee9c1e", 0.96, 0.88, 0.92, 0.76, 0.56, 0.30),
        "handle": WOOD,
    },
}

SWORD_MASK = Image.open(VANILLA / "item/diamond_sword.png").convert("RGBA")


def sword_kind(x, y):
    if 6 <= y <= 8 and x <= 6:
        return "guard"
    if (y >= 9 and x <= 6) or y >= 13:
        return "handle"
    return "blade"


def blade_facet(x, y):
    """Ramp from the spine (upper-left) to the cutting edge (lower-right)."""
    dist = (15 - x) if y <= 5 else (16 - y - x)
    if y >= 11:
        dist = 15 - x
    if dist <= 0:
        return "top"
    if dist == 1:
        return "top_right"
    if dist == 2:
        return "top_left"
    if dist == 3:
        return "left"
    return "bottom" if y >= 9 else "left"


def put(image, x, y, color):
    image.putpixel((x, y), tuple(color) + (255,) if len(color) == 3 else color)


def make_sword(name, palette, detail):
    blade, guard, handle = palette["blade"], palette["guard"], palette["handle"]
    out = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    mask = SWORD_MASK.load()
    px = out.load()
    for y in range(16):
        for x in range(16):
            if mask[x, y][3] == 0:
                continue
            k = sword_kind(x, y)
            if k == "blade":
                px[x, y] = blade[blade_facet(x, y)]
            elif k == "guard":
                px[x, y] = guard["top"] if y == 6 else guard["top_right" if x <= 3 else "left"]
            else:
                px[x, y] = handle["top"] if x <= 3 else (handle["top_left"] if y <= 12 else handle["bottom"])
    detail(out)
    out.save(TEX_ITEM / f"{name}.png")


def detail_golden_apple(image):
    # Apple crest sitting on the guard.
    for x, y in [(3, 7), (4, 7), (3, 8)]:
        put(image, x, y, rgb("#b01c26"))
    put(image, 4, 8, rgb("#e84a48"))
    put(image, 4, 6, rgb("#5cb234"))
    # White-hot tip.
    put(image, 15, 0, rgb("#ffffec"))
    put(image, 14, 0, rgb("#fff6cc"))
    put(image, 13, 1, rgb("#ffe8a6"))


def detail_enchanted(image):
    detail_golden_apple(image)
    # Crystal shards along the blade.
    for x, y in [(12, 2), (9, 5), (6, 7)]:
        put(image, x, y, rgb("#fadfef"))
    put(image, 14, 3, rgb("#ffffff"))


def detail_carrot(image):
    # Rounded tip and root rings.
    put(image, 14, 1, rgb("#ffe4aa"))
    for x, y in [(11, 3), (8, 5), (6, 9), (9, 6)]:
        put(image, x, y, rgb("#ce6212"))
    # Leaves sprouting off the guard.
    for x, y, c in [(0, 6, "#78cc48"), (1, 5, "#5eb636"), (1, 9, "#78cc48")]:
        put(image, x, y, rgb(c))


def detail_baguette(image):
    # Diagonal flour scores and a couple of crust spots.
    for x, y in [(10, 3), (9, 4), (12, 2), (8, 5), (7, 6)]:
        put(image, x, y, rgb("#f8e4c2"))
    for x, y in [(11, 4), (6, 8)]:
        put(image, x, y, rgb("#b0723e"))


def detail_honey(image):
    # Honeycomb cells on the guard and a drip hanging off the tip.
    for x, y in [(3, 7), (5, 7)]:
        put(image, x, y, rgb("#985406"))
    put(image, 4, 7, rgb("#ffc660"))
    put(image, 15, 2, rgb("#ffd87c"))
    put(image, 14, 1, rgb("#ffecb0"))


make_sword("golden_apple_sword", PALETTES["golden_apple"], detail_golden_apple)
make_sword("enchanted_golden_apple_sword", PALETTES["enchanted_golden_apple"], detail_enchanted)
make_sword("carrot_sword", PALETTES["carrot"], detail_carrot)
make_sword("baguette_sword", PALETTES["baguette"], detail_baguette)
make_sword("honey_sword", PALETTES["honey"], detail_honey)


# ---------------------------------------------------------------------------
# Ender apple: dark pearl shell with a glowing teal eye.
# ---------------------------------------------------------------------------
def make_ender_apple():
    mask = Image.open(VANILLA / "item/apple.png").convert("RGBA").load()
    out = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    shell = {
        "top": rgb("#8a5cc4"),
        "top_right": rgb("#6e46a2"),
        "top_left": rgb("#7e52b6"),
        "right": rgb("#56347e"),
        "left": rgb("#44265e"),
        "bottom": rgb("#221434"),
    }
    for y in range(16):
        for x in range(16):
            if mask[x, y][3] == 0:
                continue
            if y <= 4:
                facet = "top_right"
            elif x <= 3:
                facet = "left"
            elif x >= 12:
                facet = "right"
            elif y >= 12:
                facet = "bottom"
            elif x <= 5:
                facet = "top_left"
            else:
                facet = "top"
            out.putpixel((x, y), shell[facet] + (255,))

    # Stem and leaf.
    for x, y in [(8, 1), (8, 2), (8, 3)]:
        put(out, x, y, rgb("#3e2c1e"))
    put(out, 9, 2, rgb("#3e8456"))

    # Ender eye.
    eye = {
        (6, 8): rgb("#2a1a40"), (7, 8): rgb("#5ce8d2"), (8, 8): rgb("#5ce8d2"), (9, 8): rgb("#2a1a40"),
        (6, 9): rgb("#5ce8d2"), (7, 9): rgb("#081012"), (8, 9): rgb("#081012"), (9, 9): rgb("#5ce8d2"),
        (6, 10): rgb("#2a1a40"), (7, 10): rgb("#5ce8d2"), (8, 10): rgb("#5ce8d2"), (9, 10): rgb("#2a1a40"),
    }
    for (x, y), c in eye.items():
        put(out, x, y, c)
    put(out, 7, 8, rgb("#b6fff2"))
    put(out, 8, 10, rgb("#96f0e2"))

    # Rim light / shadow crescent.
    for x, y in [(4, 5), (5, 4), (3, 6)]:
        put(out, x, y, rgb("#c4a0e6"))
    for x, y in [(11, 12), (12, 11), (10, 13)]:
        put(out, x, y, rgb("#140a24"))
    out.save(TEX_ITEM / "ender_apple.png")


make_ender_apple()


# ---------------------------------------------------------------------------
# Helmet icon + armour sheet.
# ---------------------------------------------------------------------------
def make_helmet_icon():
    mask = Image.open(VANILLA / "item/iron_helmet.png").convert("RGBA").load()
    out = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    gold = lit("#eea61e", 1.0, 0.92, 0.96, 0.80, 0.58, 0.32)
    for y in range(16):
        for x in range(16):
            if mask[x, y][3] == 0:
                continue
            if y <= 4:
                facet = "top"
            elif x <= 4:
                facet = "top_left"
            elif x >= 11:
                facet = "top_right"
            elif y >= 9:
                facet = "left"
            else:
                facet = "top"
            out.putpixel((x, y), gold[facet])

    for x in range(5, 11):
        for y in (9, 10):
            out.putpixel((x, y), (0, 0, 0, 0))
    for x in (4, 11):
        put(out, x, 9, rgb("#764406"))
    for x in range(5, 11):
        put(out, x, 8, rgb("#96600a"))

    crest = {
        (7, 5): rgb("#961418"), (8, 5): rgb("#d62e2e"), (9, 5): rgb("#961418"),
        (7, 6): rgb("#b21c24"), (8, 6): rgb("#ff6e68"), (9, 6): rgb("#c4262a"),
        (7, 7): rgb("#801018"), (8, 7): rgb("#b21c24"), (9, 7): rgb("#801018"),
    }
    for (x, y), c in crest.items():
        put(out, x, y, c)
    put(out, 8, 4, rgb("#4e9634"))
    out.save(TEX_ITEM / "golden_apple_helmet.png")


make_helmet_icon()


def make_armor_sheet():
    """Single-hue golden armour sheet in the vanilla 64x32 layout.

    Vanilla reads the armour layer only through the RED channel, so the sheet
    must stay in one warm hue: anything blue or violet turns into a muddy
    purple helmet in game.
    """
    base = rgb("#ffd68c")
    edge = rgb("#c48c3c")
    hi = rgb("#fff6d6")
    shade = rgb("#e2a654")

    sheet = Image.new("RGBA", (64, 32), (0, 0, 0, 0))
    draw = ImageDraw.Draw(sheet)

    def plate(x0, y0, x1, y1):
        draw.rectangle((x0, y0, x1, y1), fill=base + (255,))
        draw.line((x0, y0, x1, y0), fill=hi + (255,))
        draw.line((x0, y1, x1, y1), fill=edge + (255,))
        draw.line((x0, y0, x0, y1), fill=shade + (255,))
        draw.line((x1, y0, x1, y1), fill=edge + (255,))

    # Head box (the only part a helmet uses): brow band + face opening feel.
    plate(8, 0, 15, 7)
    draw.line((8, 5, 15, 5), fill=shade + (255,))
    draw.line((9, 6, 14, 6), fill=hi + (255,))
    draw.line((9, 7, 14, 7), fill=edge + (255,))

    # Body / arms / legs (unused by the helmet, filled so the sheet is complete).
    plate(16, 8, 39, 15)
    plate(20, 16, 27, 19)
    plate(44, 16, 47, 19)
    plate(16, 20, 39, 25)
    plate(0, 26, 15, 31)

    sheet.save(TEX_ARMOR / "golden_apple_layer_1.png")


make_armor_sheet()


# ---------------------------------------------------------------------------
# Mod icon.
# ---------------------------------------------------------------------------
icon = Image.new("RGBA", (128, 128), rgb("#1b120c") + (255,))
draw = ImageDraw.Draw(icon)
for i in range(128):
    v = int(22 + 16 * (1 - abs(i - 64) / 64))
    draw.line((0, i, 128, i), fill=(v + 10, v, max(0, v - 8), 255))
draw.rounded_rectangle((4, 4, 123, 123), radius=14, outline=rgb("#d89a1c") + (255,), width=3)
draw.rounded_rectangle((10, 10, 117, 117), radius=10, outline=rgb("#693e00") + (255,), width=2)
sword = Image.open(TEX_ITEM / "golden_apple_sword.png").convert("RGBA").resize((96, 96), Image.Resampling.NEAREST)
apple_icon = Image.open(TEX_ITEM / "ender_apple.png").convert("RGBA").resize((38, 38), Image.Resampling.NEAREST)
icon.alpha_composite(sword, (16, 10))
icon.alpha_composite(apple_icon, (80, 80))
icon.save(ASSETS / "icon.png")

print("Generated textures in", ASSETS)

