package com.dsh.goldenappleworkshop.event;

import com.dsh.goldenappleworkshop.registry.ModItems;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;

public final class AppleHelmetEvents {
    private static final int CHECK_INTERVAL = 100;

    private AppleHelmetEvents() {
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                if (player.tickCount % CHECK_INTERVAL != 0) {
                    continue;
                }
                if (!player.getItemBySlot(EquipmentSlot.HEAD).is(ModItems.GOLDEN_APPLE_HELMET)) {
                    continue;
                }
                if (player.getFoodData().getFoodLevel() < 8 || player.getHealth() >= player.getMaxHealth()) {
                    continue;
                }

                player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 0, true, false, true));
                player.causeFoodExhaustion(0.4F);

                if (player.level() instanceof ServerLevel level) {
                    level.sendParticles(ParticleTypes.HEART,
                            player.getX(), player.getY() + 1.7D, player.getZ(),
                            2, 0.3D, 0.2D, 0.3D, 0.0D);
                }
            }
        });
    }
}
