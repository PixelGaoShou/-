package com.dsh.goldenappleworkshop;

import com.dsh.goldenappleworkshop.event.AppleHelmetEvents;
import com.dsh.goldenappleworkshop.registry.ModItemGroup;
import com.dsh.goldenappleworkshop.registry.ModItems;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GoldenAppleWorkshop implements ModInitializer {
    public static final String MOD_ID = "goldenappleworkshop";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModItems.init();
        ModItemGroup.init();
        AppleHelmetEvents.init();
        LOGGER.info("Golden Apple Workshop is open: seven tasty pieces of equipment are on the menu.");
    }
}
