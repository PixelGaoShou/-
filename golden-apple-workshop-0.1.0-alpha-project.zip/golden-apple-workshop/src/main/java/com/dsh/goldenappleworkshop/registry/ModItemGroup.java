package com.dsh.goldenappleworkshop.registry;

import com.dsh.goldenappleworkshop.GoldenAppleWorkshop;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;

public final class ModItemGroup {
    public static final ResourceKey<CreativeModeTab> MAIN = ResourceKey.create(
            Registries.CREATIVE_MODE_TAB,
            new ResourceLocation(GoldenAppleWorkshop.MOD_ID, "main")
    );

    private ModItemGroup() {
    }

    public static void init() {
        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, MAIN, FabricItemGroup.builder()
                .title(Component.translatable("itemGroup.goldenappleworkshop.main"))
                .icon(() -> new ItemStack(ModItems.GOLDEN_APPLE_SWORD))
                .displayItems((parameters, output) -> {
                    output.accept(ModItems.GOLDEN_APPLE_SWORD);
                    output.accept(ModItems.ENCHANTED_GOLDEN_APPLE_SWORD);
                    output.accept(ModItems.CARROT_SWORD);
                    output.accept(ModItems.BAGUETTE_SWORD);
                    output.accept(ModItems.HONEY_SWORD);
                    output.accept(ModItems.ENDER_APPLE);
                    output.accept(ModItems.GOLDEN_APPLE_HELMET);
                })
                .build());
    }
}
