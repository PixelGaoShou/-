package com.dsh.goldenappleworkshop.registry;

import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterials;

/**
 * The Golden Apple Helmet reuses the vanilla GOLD armor material directly.
 *
 * <p>That makes the worn helmet go through the exact same code path as a vanilla
 * golden helmet (same model, renderer and texture pipeline), so there is no
 * custom client rendering that could break.</p>
 */
public final class ModArmorMaterials {
    public static final ArmorMaterials GOLDEN_APPLE = ArmorMaterials.GOLD;

    private ModArmorMaterials() {
    }

    /** True when the item is the helmet slot piece of this material. */
    public static boolean isHelmet(ArmorItem.Type type) {
        return type == ArmorItem.Type.HELMET;
    }
}
