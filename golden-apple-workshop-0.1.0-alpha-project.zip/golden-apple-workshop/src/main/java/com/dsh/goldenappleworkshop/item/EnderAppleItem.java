package com.dsh.goldenappleworkshop.item;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class EnderAppleItem extends Item {
    private static final int EAT_DURATION = 28;
    private static final int COOLDOWN_TICKS = 160;
    private static final double MIN_DISTANCE = 8.0D;
    private static final double MAX_DISTANCE = 24.0D;
    private static final int ATTEMPTS = 40;
    private final List<Component> tooltip;

    public EnderAppleItem(Properties properties, List<Component> tooltip) {
        super(properties);
        this.tooltip = tooltip;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.fail(stack);
        }

        player.startUsingItem(hand);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return EAT_DURATION;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.EAT;
    }

    @Override
    public SoundEvent getEatingSound() {
        return SoundEvents.GENERIC_EAT;
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (!level.isClientSide && entity instanceof Player player && level instanceof ServerLevel serverLevel) {
            player.getFoodData().eat(4, 0.4F);
            boolean moved = tryTeleport(serverLevel, player);

            player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 200, 0, false, true, true));
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 100, 0, false, true, true));

            if (moved) {
                player.playSound(SoundEvents.CHORUS_FRUIT_TELEPORT, 1.0F, 1.0F);
            } else {
                player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 120, 0, false, true, true));
                player.displayClientMessage(Component.translatable("message.goldenappleworkshop.ender_apple.failed"), true);
                player.playSound(SoundEvents.ENDERMAN_TELEPORT, 0.7F, 0.6F);
            }

            player.getCooldowns().addCooldown(this, COOLDOWN_TICKS);
            if (!player.getAbilities().instabuild) {
                stack.shrink(1);
            }
        }

        return stack;
    }

    private static boolean tryTeleport(ServerLevel level, Player player) {
        Vec3 origin = player.position();
        AABB originalBox = player.getBoundingBox();

        for (int attempt = 0; attempt < ATTEMPTS; attempt++) {
            double angle = player.getRandom().nextDouble() * Math.PI * 2.0D;
            double distance = MIN_DISTANCE + player.getRandom().nextDouble() * (MAX_DISTANCE - MIN_DISTANCE);
            double x = origin.x + Math.cos(angle) * distance;
            double z = origin.z + Math.sin(angle) * distance;
            double y = origin.y + player.getRandom().nextInt(9) - 4;

            BlockPos landing = BlockPos.containing(x, y, z);
            if (!level.isInWorldBounds(landing) || !level.isInWorldBounds(landing.below())) {
                continue;
            }
            if (level.getFluidState(landing.below()).is(FluidTags.LAVA)
                    || level.getFluidState(landing).is(FluidTags.LAVA)) {
                continue;
            }

            AABB movedBox = originalBox.move(x - origin.x, y - origin.y, z - origin.z);
            if (!level.noCollision(player, movedBox)) {
                continue;
            }

            level.sendParticles(ParticleTypes.PORTAL, origin.x, origin.y + 1.0D, origin.z,
                    24, 0.4D, 0.8D, 0.4D, 0.15D);
            player.teleportTo(x, y, z);
            player.resetFallDistance();
            level.sendParticles(ParticleTypes.REVERSE_PORTAL, x, y + 1.0D, z,
                    36, 0.5D, 0.9D, 0.5D, 0.2D);
            return true;
        }

        return false;
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> lines, TooltipFlag flag) {
        super.appendHoverText(stack, level, lines, flag);
        for (Component line : tooltip) {
            lines.add(line.copy());
        }
    }
}
