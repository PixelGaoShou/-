package com.dsh.goldenappleworkshop.registry;

import com.dsh.goldenappleworkshop.GoldenAppleWorkshop;
import com.dsh.goldenappleworkshop.item.EnderAppleItem;
import com.dsh.goldenappleworkshop.item.GoldenAppleHelmetItem;
import com.dsh.goldenappleworkshop.item.TastySwordItem;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public final class ModItems {
    public static final Item GOLDEN_APPLE_SWORD = register("golden_apple_sword",
            new TastySwordItem(ModTiers.GOLDEN_APPLE, 3, -2.0F, new Item.Properties().rarity(Rarity.UNCOMMON),
                    5, 0.6F, true, 14, 160,
                    player -> {
                        player.addEffect(TastySwordItem.effect(MobEffects.REGENERATION, 100, 0));
                        player.addEffect(TastySwordItem.effect(MobEffects.ABSORPTION, 200, 0));
                    },
                    (level, attacker, target) -> {
                        if (attacker.getRandom().nextFloat() < 0.35F) {
                            attacker.heal(2.0F);
                            attacker.addEffect(TastySwordItem.effect(MobEffects.ABSORPTION, 160, 0));
                            level.sendParticles(ParticleTypes.HEART,
                                    attacker.getX(), attacker.getY() + 1.0D, attacker.getZ(),
                                    4, 0.35D, 0.35D, 0.35D, 0.02D);
                            level.playSound(null, attacker.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP,
                                    SoundSource.PLAYERS, 0.55F, 1.4F);
                        }
                    },
                    List.of(
                            tip("tooltip.goldenappleworkshop.golden_apple_sword.hit", ChatFormatting.GOLD),
                            tip("tooltip.goldenappleworkshop.golden_apple_sword.eat", ChatFormatting.GREEN),
                            tip("tooltip.goldenappleworkshop.golden_apple_sword.cost", ChatFormatting.DARK_GRAY)
                    )));

    public static final Item ENCHANTED_GOLDEN_APPLE_SWORD = register("enchanted_golden_apple_sword",
            new TastySwordItem(ModTiers.ENCHANTED_GOLDEN_APPLE, 3, -2.2F,
                    new Item.Properties().rarity(Rarity.EPIC),
                    8, 0.9F, true, 24, 400,
                    player -> {
                        player.addEffect(TastySwordItem.effect(MobEffects.REGENERATION, 160, 1));
                        player.addEffect(TastySwordItem.effect(MobEffects.ABSORPTION, 1200, 1));
                        player.addEffect(TastySwordItem.effect(MobEffects.DAMAGE_RESISTANCE, 100, 0));
                        player.addEffect(TastySwordItem.effect(MobEffects.FIRE_RESISTANCE, 400, 0));
                        player.playSound(SoundEvents.TOTEM_USE, 0.45F, 1.25F);
                    },
                    (level, attacker, target) -> {
                        if (attacker.getRandom().nextFloat() < 0.6F) {
                            attacker.heal(1.0F);
                            attacker.addEffect(TastySwordItem.effect(MobEffects.REGENERATION, 60, 0));
                            attacker.addEffect(TastySwordItem.effect(MobEffects.ABSORPTION, 240, 0));
                            target.addEffect(TastySwordItem.effect(MobEffects.WEAKNESS, 60, 0));
                            target.addEffect(TastySwordItem.effect(MobEffects.GLOWING, 100, 0));
                            level.sendParticles(ParticleTypes.ENCHANT,
                                    target.getX(), target.getY() + 1.0D, target.getZ(),
                                    16, 0.5D, 0.8D, 0.5D, 0.4D);
                            level.sendParticles(ParticleTypes.TOTEM_OF_UNDYING,
                                    attacker.getX(), attacker.getY() + 1.0D, attacker.getZ(),
                                    3, 0.3D, 0.5D, 0.3D, 0.2D);
                            level.playSound(null, attacker.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME,
                                    SoundSource.PLAYERS, 0.45F, 1.6F);
                        }
                    },
                    List.of(
                            tip("tooltip.goldenappleworkshop.enchanted_golden_apple_sword.hit", ChatFormatting.LIGHT_PURPLE),
                            tip("tooltip.goldenappleworkshop.enchanted_golden_apple_sword.eat", ChatFormatting.GREEN),
                            tip("tooltip.goldenappleworkshop.enchanted_golden_apple_sword.cost", ChatFormatting.DARK_GRAY)
                    )) {
                @Override
                public boolean isFoil(ItemStack stack) {
                    return true;
                }
            });

    public static final Item CARROT_SWORD = register("carrot_sword",
            new TastySwordItem(ModTiers.CARROT, 3, -1.2F, new Item.Properties(),
                    3, 0.4F, false, 10, 80,
                    player -> {
                        player.addEffect(TastySwordItem.effect(MobEffects.MOVEMENT_SPEED, 160, 1));
                        player.addEffect(TastySwordItem.effect(MobEffects.JUMP, 120, 1));
                        player.playSound(SoundEvents.RABBIT_JUMP, 0.8F, 1.4F);
                    },
                    (level, attacker, target) -> {
                        if (attacker.getRandom().nextFloat() < 0.3F) {
                            attacker.addEffect(TastySwordItem.effect(MobEffects.MOVEMENT_SPEED, 80, 0));
                            attacker.addEffect(TastySwordItem.effect(MobEffects.JUMP, 60, 1));
                        }
                        if (attacker.getRandom().nextFloat() < 0.1F) {
                            target.spawnAtLocation(new ItemStack(Items.CARROT));
                        }
                        level.sendParticles(ParticleTypes.HAPPY_VILLAGER,
                                target.getX(), target.getY() + 0.8D, target.getZ(),
                                5, 0.35D, 0.35D, 0.35D, 0.0D);
                    },
                    List.of(
                            tip("tooltip.goldenappleworkshop.carrot_sword.hit", ChatFormatting.GOLD),
                            tip("tooltip.goldenappleworkshop.carrot_sword.eat", ChatFormatting.GREEN),
                            tip("tooltip.goldenappleworkshop.carrot_sword.cost", ChatFormatting.DARK_GRAY)
                    )));

    public static final Item BAGUETTE_SWORD = register("baguette_sword",
            new TastySwordItem(ModTiers.BAGUETTE, 3, -2.8F, new Item.Properties(),
                    6, 0.8F, false, 12, 120,
                    player -> {
                        player.addEffect(TastySwordItem.effect(MobEffects.DAMAGE_BOOST, 120, 0));
                        player.playSound(SoundEvents.PLAYER_BURP, 0.65F, 0.9F);
                    },
                    (level, attacker, target) -> {
                        Vec3 delta = target.position().subtract(attacker.position());
                        Vec3 flat = new Vec3(delta.x, 0.0D, delta.z);
                        if (flat.lengthSqr() > 0.0001D) {
                            flat = flat.normalize();
                            target.push(flat.x * 0.9D, 0.28D, flat.z * 0.9D);
                        }
                        target.addEffect(TastySwordItem.effect(MobEffects.MOVEMENT_SLOWDOWN, 30, 1));
                        level.sendParticles(ParticleTypes.CRIT,
                                target.getX(), target.getY() + 0.9D, target.getZ(),
                                8, 0.4D, 0.4D, 0.4D, 0.15D);
                        level.playSound(null, target.blockPosition(), SoundEvents.PLAYER_ATTACK_KNOCKBACK,
                                SoundSource.PLAYERS, 0.8F, 0.7F);
                    },
                    List.of(
                            tip("tooltip.goldenappleworkshop.baguette_sword.hit", ChatFormatting.GOLD),
                            tip("tooltip.goldenappleworkshop.baguette_sword.eat", ChatFormatting.GREEN),
                            tip("tooltip.goldenappleworkshop.baguette_sword.cost", ChatFormatting.DARK_GRAY)
                    )));

    public static final Item HONEY_SWORD = register("honey_sword",
            new TastySwordItem(ModTiers.HONEY, 3, -2.1F, new Item.Properties(),
                    4, 0.3F, true, 10, 100,
                    player -> {
                        player.addEffect(TastySwordItem.effect(MobEffects.REGENERATION, 100, 0));
                        player.addEffect(TastySwordItem.effect(MobEffects.MOVEMENT_SPEED, 120, 0));
                        player.playSound(SoundEvents.HONEY_DRINK, 0.8F, 1.0F);
                    },
                    (level, attacker, target) -> {
                        if (attacker.getRandom().nextFloat() < 0.5F) {
                            target.addEffect(TastySwordItem.effect(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
                            target.addEffect(TastySwordItem.effect(MobEffects.WEAKNESS, 40, 0));
                            level.sendParticles(ParticleTypes.FALLING_HONEY,
                                    target.getX(), target.getY() + 1.0D, target.getZ(),
                                    10, 0.35D, 0.6D, 0.35D, 0.0D);
                            level.playSound(null, target.blockPosition(), SoundEvents.HONEY_BLOCK_SLIDE,
                                    SoundSource.PLAYERS, 0.55F, 1.5F);
                        }
                    },
                    List.of(
                            tip("tooltip.goldenappleworkshop.honey_sword.hit", ChatFormatting.GOLD),
                            tip("tooltip.goldenappleworkshop.honey_sword.eat", ChatFormatting.GREEN),
                            tip("tooltip.goldenappleworkshop.honey_sword.cost", ChatFormatting.DARK_GRAY)
                    )));

    public static final Item ENDER_APPLE = register("ender_apple",
            new EnderAppleItem(new Item.Properties().stacksTo(16).rarity(Rarity.RARE),
                    List.of(
                            tip("tooltip.goldenappleworkshop.ender_apple.teleport", ChatFormatting.LIGHT_PURPLE),
                            tip("tooltip.goldenappleworkshop.ender_apple.safe", ChatFormatting.GREEN),
                            tip("tooltip.goldenappleworkshop.ender_apple.cost", ChatFormatting.DARK_GRAY)
                    )));

    public static final Item GOLDEN_APPLE_HELMET = register("golden_apple_helmet",
            new GoldenAppleHelmetItem(ModArmorMaterials.GOLDEN_APPLE, ArmorItem.Type.HELMET,
                    new Item.Properties().rarity(Rarity.RARE),
                    List.of(
                            tip("tooltip.goldenappleworkshop.golden_apple_helmet.regen", ChatFormatting.GOLD),
                            tip("tooltip.goldenappleworkshop.golden_apple_helmet.hunger", ChatFormatting.GREEN),
                            tip("tooltip.goldenappleworkshop.golden_apple_helmet.piglin", ChatFormatting.YELLOW)
                    )));

    private ModItems() {
    }

    public static void init() {
        // Class loading performs the registrations above.
    }

    private static Item register(String name, Item item) {
        return Registry.register(BuiltInRegistries.ITEM,
                new ResourceLocation(GoldenAppleWorkshop.MOD_ID, name), item);
    }

    private static Component tip(String key, ChatFormatting color) {
        return Component.translatable(key).withStyle(color);
    }
}
