package com.dsh.goldenappleworkshop.item;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;

import java.util.List;
import java.util.function.Consumer;

/**
 * A sword you can also take a bite out of. Eating never consumes the item itself;
 * it spends durability instead, so the weapon stays in your hand.
 */
public class TastySwordItem extends SwordItem {
    @FunctionalInterface
    public interface HitEffect {
        void onHit(ServerLevel level, Player attacker, LivingEntity target);
    }

    private final int nutrition;
    private final float saturationModifier;
    private final boolean alwaysEdible;
    private final int eatDurabilityCost;
    private final int eatCooldownTicks;
    private final Consumer<Player> eatEffect;
    private final HitEffect hitEffect;
    private final List<Component> tooltip;

    public TastySwordItem(Tier tier,
                          int attackDamage,
                          float attackSpeed,
                          Properties properties,
                          int nutrition,
                          float saturationModifier,
                          boolean alwaysEdible,
                          int eatDurabilityCost,
                          int eatCooldownTicks,
                          Consumer<Player> eatEffect,
                          HitEffect hitEffect,
                          List<Component> tooltip) {
        super(tier, attackDamage, attackSpeed, properties);
        this.nutrition = nutrition;
        this.saturationModifier = saturationModifier;
        this.alwaysEdible = alwaysEdible;
        this.eatDurabilityCost = eatDurabilityCost;
        this.eatCooldownTicks = eatCooldownTicks;
        this.eatEffect = eatEffect;
        this.hitEffect = hitEffect;
        this.tooltip = tooltip;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(this) || !player.canEat(alwaysEdible)) {
            return InteractionResultHolder.fail(stack);
        }

        player.startUsingItem(hand);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 24;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.EAT;
    }

    @Override
    public SoundEvent getEatingSound() {
        return SoundEvents.GENERIC_EAT;
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (!level.isClientSide && entity instanceof Player player) {
            player.getFoodData().eat(nutrition, saturationModifier);
            player.playSound(SoundEvents.GENERIC_EAT, 0.85F, 0.9F + player.getRandom().nextFloat() * 0.2F);

            if (!player.getAbilities().instabuild && eatDurabilityCost > 0 && stack.isDamageableItem()) {
                stack.hurtAndBreak(eatDurabilityCost, player,
                        broken -> broken.broadcastBreakEvent(player.getUsedItemHand()));
            }

            eatEffect.accept(player);

            if (eatCooldownTicks > 0) {
                player.getCooldowns().addCooldown(this, eatCooldownTicks);
            }
        }

        return stack;
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean result = super.hurtEnemy(stack, target, attacker);
        if (result && !attacker.level().isClientSide && attacker instanceof Player player && target.isAlive()) {
            hitEffect.onHit((ServerLevel) attacker.level(), player, target);
        }
        return result;
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> lines, TooltipFlag flag) {
        super.appendHoverText(stack, level, lines, flag);
        for (Component line : tooltip) {
            lines.add(line.copy());
        }
    }

    public static MobEffectInstance effect(net.minecraft.world.effect.MobEffect effect, int duration, int amplifier) {
        return new MobEffectInstance(effect, duration, amplifier, false, true, true);
    }
}
