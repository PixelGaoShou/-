package com.dsh.goldenappleworkshop.registry;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

import java.util.function.Supplier;

public enum ModTiers implements Tier {
    GOLDEN_APPLE(420, 8.0F, 2.5F, 2, 22, () -> Ingredient.of(Items.GOLDEN_APPLE)),
    ENCHANTED_GOLDEN_APPLE(999, 9.0F, 4.0F, 4, 30, () -> Ingredient.of(Items.ENCHANTED_GOLDEN_APPLE)),
    CARROT(220, 6.0F, 1.0F, 1, 15, () -> Ingredient.of(Items.CARROT)),
    BAGUETTE(380, 4.0F, 2.0F, 1, 10, () -> Ingredient.of(Items.BREAD)),
    HONEY(300, 5.0F, 1.5F, 2, 18, () -> Ingredient.of(Items.HONEYCOMB));

    private final int uses;
    private final float speed;
    private final float attackDamageBonus;
    private final int level;
    private final int enchantmentValue;
    private final Supplier<Ingredient> repairIngredient;

    ModTiers(int uses, float speed, float attackDamageBonus, int level, int enchantmentValue, Supplier<Ingredient> repairIngredient) {
        this.uses = uses;
        this.speed = speed;
        this.attackDamageBonus = attackDamageBonus;
        this.level = level;
        this.enchantmentValue = enchantmentValue;
        this.repairIngredient = repairIngredient;
    }

    @Override
    public int getUses() {
        return uses;
    }

    @Override
    public float getSpeed() {
        return speed;
    }

    @Override
    public float getAttackDamageBonus() {
        return attackDamageBonus;
    }

    @Override
    public int getLevel() {
        return level;
    }

    @Override
    public int getEnchantmentValue() {
        return enchantmentValue;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return repairIngredient.get();
    }
}
