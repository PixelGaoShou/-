package com.dsh.goldenappleworkshop.item;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

public class GoldenAppleHelmetItem extends ArmorItem {
    private final List<Component> tooltip;

    public GoldenAppleHelmetItem(ArmorMaterial material, Type type, Properties properties, List<Component> tooltip) {
        super(material, type, properties);
        this.tooltip = tooltip;
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> lines, TooltipFlag flag) {
        super.appendHoverText(stack, level, lines, flag);
        for (Component line : tooltip) {
            lines.add(line.copy());
        }
    }
}
